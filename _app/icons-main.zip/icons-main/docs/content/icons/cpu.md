---
title: CPU
categories:
  - Deviecs
tags:
  - processor
  - chip
  - computer
---
