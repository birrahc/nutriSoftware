---
title: Envelope
categories:
  - Communications
tags:
  - email
  - message
  - mail
---
