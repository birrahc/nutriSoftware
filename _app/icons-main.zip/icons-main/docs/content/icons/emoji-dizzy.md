---
title: Emoji dizzy
layout: icon
categories:
  - Emoji
tags:
  - emoticon
---
