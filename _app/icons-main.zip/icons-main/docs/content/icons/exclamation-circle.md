---
title: Alert circle
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
