---
title: Emoji smile
layout: icon
categories:
  - Emoji
tags:
  - emoticon
  - happy
---
