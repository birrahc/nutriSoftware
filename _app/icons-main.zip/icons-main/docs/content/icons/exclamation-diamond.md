---
title: Exclamation diamond
categories:
  - Alerts, warnings, and signs
tags:
  - alert
  - warning
---
